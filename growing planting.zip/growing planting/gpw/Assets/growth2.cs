﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using System.Collections;
public class growth2 : MonoBehaviour
{
    float time = 0.0f;
    bool newplant = true;
    public KeyCode plantkey;
    public GameObject flower;
    public GameObject stage3;
    
    void Start()
    {
        Vector3 position = transform.localPosition;
        position.x = position.x + 1;
        position.y = -0.33f;
        transform.localPosition = position;
    }



    void Update()
    {

        bool plantflower = Input.GetKey(plantkey);
        

        time += Time.deltaTime;
        
        if (newplant)
        {
            
            newplant = false;
        }
        if (time > 5)
        {
            stage3.gameObject.SetActive(true);
            flower.gameObject.SetActive(false);
        }
        

    }
}
