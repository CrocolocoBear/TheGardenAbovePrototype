﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using System.Collections;
public class plant : MonoBehaviour
{
    // Start is called before the first frame update
    public float time = 0.0f;
    bool timestart;

    public GameObject stage1;
    public GameObject stage2;
    public GameObject stage3;
    public KeyCode plantkey;

    void Update()
    {
        Vector3 position = transform.localPosition;
        bool plantflower = Input.GetKey(plantkey);
        
        if (plantflower)
        {
            stage1.gameObject.SetActive(true);
        }
        
        
    }

}

