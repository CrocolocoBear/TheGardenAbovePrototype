﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using System.Collections;
public class growth : MonoBehaviour
{
    float time = 0.0f;
    public KeyCode plantkey;
    public GameObject flower;
    public GameObject stage2;
    public GameObject stage3;
    public bool oneobject;
    public bool instant;
    void Start()
    {
        Vector3 position = transform.localPosition;
        position.x = position.x + 1;
        position.y = -0.33f;
        transform.localPosition = position;
    }



    void Update()
    {
        
        bool plantflower = Input.GetKey(plantkey);
        time += Time.deltaTime;
        Vector3 scale = transform.localScale;
        if (oneobject)
        {
            if (instant)
            {
                flower.gameObject.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
            }
            else
            {
                if (time > 5)
                {
                    flower.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
                }
                if (time > 10)
                {
                    flower.gameObject.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                }
            }
        }
        else
        {
            if (instant)
            {
                stage3.gameObject.SetActive(true);
                flower.gameObject.SetActive(false);
            }
            else
            {
                if (time > 5)
                {
                    stage2.gameObject.SetActive(true);
                    flower.gameObject.SetActive(false);
                }
            }
        }
        
        
    }
}
