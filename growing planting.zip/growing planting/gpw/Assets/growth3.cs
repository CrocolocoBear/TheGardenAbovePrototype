﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using System.Collections;
public class growth3 : MonoBehaviour
{
    bool newplant = true;
    public KeyCode plantkey;
    public GameObject flower;
    void Start()
    {
        Vector3 position = transform.localPosition;
        position.x = position.x + 1;
        position.y = -0.33f;
        transform.localPosition = position;
    }



    void Update()
    {

        bool plantflower = Input.GetKey(plantkey);
        
        
        if (newplant)
        {
            
            newplant = false;
        }

    }
}
