﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using System.Collections;
public class growth : MonoBehaviour
{
    float time = 0.0f;
    public KeyCode plantkey;
    public GameObject flower;
    public GameObject stage2;
    public GameObject stage3;
    public GameObject terrain;
    public bool oneobject;
    public bool instant;
    bool newplant = true;
    void Start()
    {
        
    }



    void Update()
    {
        Vector3 terrainpos = terrain.transform.position;
        if (newplant)
        { 
            terrainpos.x += 1;
            terrainpos.y += 0.42f;
            transform.localPosition = terrainpos;
            newplant = false;
        }
        bool plantflower = Input.GetKey(plantkey);

        
        time += Time.deltaTime;
        Vector3 scale = transform.localScale;
        if (oneobject)
        {
            if (instant)
            {
                flower.gameObject.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                terrainpos.y += 0.20f;
            }
            else
            {
                if (time > 5)
                {
                    flower.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
                    terrainpos.y += 0.12f;
                }
                if (time > 10)
                {
                    flower.gameObject.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                    terrainpos.y += 0.08f;
                }
            }
        }
        else
        {
            if (instant)
            {
                stage3.gameObject.SetActive(true);
                flower.gameObject.SetActive(false);
            }
            else
            {
                if (time > 5)
                {
                    stage2.gameObject.SetActive(true);
                    flower.gameObject.SetActive(false);
                }
            }
        }
        
        
    }
}
