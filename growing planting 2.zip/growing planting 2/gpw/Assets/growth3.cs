﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using System.Collections;
public class growth3 : MonoBehaviour
{
    bool newplant = true;
    public KeyCode plantkey;
    public GameObject flower;
    public GameObject terrain;
    void Start()
    {
        Vector3 terrainpos = terrain.transform.position;
        terrainpos.x += 1;
        terrainpos.y += 0.62f;
        transform.localPosition = terrainpos;
    }



    void Update()
    {

        bool plantflower = Input.GetKey(plantkey);
        
        
        if (newplant)
        {
            
            newplant = false;
        }

    }
}
