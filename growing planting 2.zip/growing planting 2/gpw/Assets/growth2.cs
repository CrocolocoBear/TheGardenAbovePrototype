﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;
using System.Collections;
public class growth2 : MonoBehaviour
{
    float time = 0.0f;
    bool newplant = true;
    public KeyCode plantkey;
    public GameObject flower;
    public GameObject stage3;
    public GameObject terrain;
    void Start()
    {
        Vector3 terrainpos = terrain.transform.position;
        terrainpos.x += 1;
        terrainpos.y += 0.54f;
        transform.localPosition = terrainpos;
    }



    void Update()
    {

        bool plantflower = Input.GetKey(plantkey);
        

        time += Time.deltaTime;
        
        if (newplant)
        {
            
            newplant = false;
        }
        if (time > 5)
        {
            stage3.gameObject.SetActive(true);
            flower.gameObject.SetActive(false);
        }
        

    }
}
